[Google Spreadsheet PHP Helper Class][gss]
=========================

Please read the [extended documentation][gss] for full details.

[gss]: http://farinspace.com/2009/05/saving-form-data-to-google-spreadsheets/ "Google Spreadsheet"